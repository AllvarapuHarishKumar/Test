package com.cutm.register;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Register
 */
@WebServlet("/Register")
public class Register extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public void doPost(HttpServletRequest request, HttpServletResponse response)    throws ServletException, IOException{
	
	response.setContentType("text/html");
	PrintWriter pw = response.getWriter();
	String connectionURL = "jdbc:mysql://localhost:3306/demodatabase3";// demodatabase3 is the database
	Connection connection;
	try{
	String username = request.getParameter("username");
	String email = request.getParameter("email");
	String phonenumber = request.getParameter("phonenumber");
	String password1=request.getParameter("password1");
	String password2=request.getParameter("password2");


Class.forName("com.mysql.jdbc.Driver");
connection = DriverManager.getConnection(connectionURL, "root", "Welcome123");
java.sql.Statement st = connection.createStatement();
ResultSet rs=null;
RequestDispatcher rd=null;


int i = st.executeUpdate("insert into register(username,email,phonenumber,password1,password2) values('"+username+"','"+email+"','"+phonenumber+"','"+password1+"','"+password2+"')");
if(i!=0){
	response.sendRedirect("login.jsp");  
}
else{
	response.sendRedirect("error404.jsp"); 
}
}
catch (Exception e){
pw.println(e);
}
}
}		
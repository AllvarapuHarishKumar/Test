package com.dp.forgetpassword.model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletContext;

public class ForgetPass1 {
	
	public int validateUserName(String username, ServletContext ctx) {
		
		int userid = 0;

		String url = ctx.getInitParameter("DBURL");
		String user = ctx.getInitParameter("DBUSER");
		String pass = ctx.getInitParameter("DBPWD");
		String driver = ctx.getInitParameter("DBDRIVER");
		
		Connection con=null;
		//PreparedStatement pst=null;
		Statement st=null;
		ResultSet rs=null;
				
		try
		{
			Class.forName(driver);
			con=DriverManager.getConnection(url,user,pass);
			
			st = con.createStatement();
			
			rs = st.executeQuery("select userid from register1 where username='"+username+"'");

			while(rs.next()) {
				
				userid = rs.getInt("userid");
				
			}

			//System.out.println("Registration succesfull");
			
			rs.close();
			st.close();
			//pst.close();
			con.close();
		}
		catch (ClassNotFoundException e) 
		{
			e.printStackTrace();
		}
		catch(SQLException sql)
		{
			sql.printStackTrace();
		}
		
		return userid;
		
	}

}

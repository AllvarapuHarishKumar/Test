package com.dp.forgetpassword.model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletContext;

import com.dp.encrypt.password.Password;

public class ForgetPass3 { // Change Password Class
	
	public void changePassword(int userid,String newPassword, ServletContext ctx) { // Change the password of the user with username

		String url = ctx.getInitParameter("DBURL");
		String user = ctx.getInitParameter("DBUSER");
		String pass = ctx.getInitParameter("DBPWD");
		String driver = ctx.getInitParameter("DBDRIVER");
				
		newPassword = new Password().decryptPassword(newPassword);
		
		Connection con=null;
		//PreparedStatement pst=null;
		Statement st=null;
		//ResultSet rs=null;
				
		try
		{
			Class.forName(driver);
			con=DriverManager.getConnection(url,user,pass);
			
			st = con.createStatement();
			
			st.executeUpdate("update register1 set password='"+newPassword+"' where userid="+userid+"");

			//System.out.println("Change Password Successful");
			
			//rs.close();
			st.close();
			//pst.close();
			con.close();
		}
		catch (ClassNotFoundException e) 
		{
			e.printStackTrace();
		}
		catch(SQLException sql)
		{
			sql.printStackTrace();
		}
		
	}
	
	public boolean validatePassword(int userid, String oldPassword, ServletContext ctx) { // Validate the old password the user with username

		String url = ctx.getInitParameter("DBURL");
		String user = ctx.getInitParameter("DBUSER");
		String pass = ctx.getInitParameter("DBPWD");
		String driver = ctx.getInitParameter("DBDRIVER");
		
		oldPassword = new Password().decryptPassword(oldPassword);
		
		String password = null;
		
		Connection con=null;
		//PreparedStatement pst=null;
		Statement st=null;
		ResultSet rs=null;
				
		try
		{
			Class.forName(driver);
			con=DriverManager.getConnection(url,user,pass);
			
			st = con.createStatement();
			
			rs = st.executeQuery("select password from register1 where userid='"+userid+"'");

			while(rs.next()) {
				
				password = rs.getString("password");
				
			}

			//System.out.println("Registration succesfull");
			
			rs.close();
			st.close();
			//pst.close();
			con.close();
		}
		catch (ClassNotFoundException e) 
		{
			e.printStackTrace();
		}
		catch(SQLException sql)
		{
			sql.printStackTrace();
		}
		
		if(oldPassword.equals(password)) {
			return true;
		}
		else {
			return false;
		}
	}

}

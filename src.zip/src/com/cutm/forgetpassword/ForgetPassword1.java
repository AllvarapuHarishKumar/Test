package com.cutm.forgetpassword;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cutm.forgetpassword.model.ForgetPass1;
import com.cutm.login.model.LoginCheck;

/**
 * Servlet implementation class ForgetPassword1
 */
@WebServlet("/ForgetPassword1")
public class ForgetPassword1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		ServletContext ctx = request.getServletContext();
		RequestDispatcher rd = null;
		
		HttpSession session = request.getSession();
		LoginCheck checkUserType = new LoginCheck();
		
		String username = null;
		
		username = request.getParameter("username");
		
		ForgetPass1 forget1 = new ForgetPass1();
		
		int userid = forget1.validateUserName(username,ctx);
		if(userid != 0) {
			
			int usertype = checkUserType.validateUser(userid,ctx);
			
			session.setAttribute("userid",userid);
	    	session.setAttribute("usertype", usertype);
			
			//request.setAttribute("Next Security Question");
			response.sendRedirect("forgetpassword1.jsp");
			
		}
		else {
			
			//request.setAttribute("fail", "INVALID USERNAME");
			String msg = "INVALID USERNAME";
			request.setAttribute("msg", msg);
			rd = request.getRequestDispatcher("forgetpassword.jsp");
			rd.forward(request, response);
			
		}
				
	}

}

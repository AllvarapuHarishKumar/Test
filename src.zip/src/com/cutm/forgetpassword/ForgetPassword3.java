package com.dp.forgetpassword;

import java.io.IOException;
//import java.io.PrintWriter;








import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dp.encrypt.password.Password;
import com.dp.forgetpassword.model.ForgetPass3;

/**
 * Servlet implementation class ForgetPassword3
 */
@WebServlet("/ForgetPassword3")
public class ForgetPassword3 extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
    
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		response.setContentType("text/html");
		//PrintWriter out = response.getWriter();
		ServletContext ctx = request.getServletContext();
		HttpSession session=request.getSession(true);
		
		System.out.println(session);
		System.out.println(session.getAttribute("userid"));
		System.out.println(session.getAttribute("usertype"));
		
		String uid ="" + session.getAttribute("userid");
		int userid = Integer.parseInt(uid);
		System.out.println(uid);
		
		String password = null;
		
		ForgetPass3 forget3 = new ForgetPass3();
		
		password = request.getParameter("password");
		
		password = new Password().encryptPassword(password);

		forget3.changePassword(userid,password,ctx);
		response.sendRedirect("login.jsp");
	
		//request.setAttribute("fail", "PASSWORD DOES NOT MATCH");
			
	}

}

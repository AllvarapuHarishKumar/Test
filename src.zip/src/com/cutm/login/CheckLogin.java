package com.cutm.login;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletContext;

/*import com.ess.forgetpassword.model.ForgetPass1;
import com.ess.forgetpassword.model.ForgetPass3;*/

public class CheckLogin {
	
	public int validateLogin(String username, String password1, 
			ServletContext ctx) {
		int userId = 0;
		
		
		//Program		
		String url = ctx.getInitParameter("DBURL");
		String user = ctx.getInitParameter("DBUSER");
		String pass = ctx.getInitParameter("DBPWD");
		String driver = ctx.getInitParameter("DBDRIVER");
	
		
		String usertype = null;
		String psw= null;
		
		try
		{
			Class.forName(driver);
		Connection con=null;
	
		con=DriverManager.getConnection(url,user,pass);
		//PreparedStatement pst=null;
		Statement st=con.createStatement();
		        ResultSet rs = st.executeQuery("SELECT password1, "+ "userid from register where username='"+username+"'");  
		while(rs.next())
		{
		psw = rs.getString("password1");
		if(psw.equalsIgnoreCase(password1))
		userId = rs.getInt("userid");
		else
			userId = 0;
		}
		  
		rs.close();
		st.close();
		con.close();
		
				
	}
				catch(SQLException e){
					e.printStackTrace();
				}
		catch(ClassNotFoundException e)
		{
			e.printStackTrace();
		}
		return userId;
	}
	
	
}

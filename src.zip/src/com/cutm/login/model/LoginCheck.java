package com.cutm.login.model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletContext;
import com.cutm.forgetpassword.model.ForgetPass1;
import com.cutm.forgetpassword.model.ForgetPass3;

public class LoginCheck {
	
	public int validateLogin(String username, String password, ServletContext ctx) {
		
		ForgetPass1 obj1 = new ForgetPass1();
		ForgetPass3 obj2 = new ForgetPass3();
		
		int userid = obj1.validateUserName(username,ctx);
				
		if(userid>0) {
			
			if(obj2.validatePassword(userid,password,ctx)) {
				//TRUE: LOGIN SUCCESSFUL
				return userid;
								
			}
			else {
			//FALSE: LOGIN UNSUCCESSFUL
				return 0;
				
			}
		}
		else {
			//FALSE: LOGIN UNSUCCESSFUL
			return 0;
			
		}
	
	}
	public int validateUser(int userid, ServletContext ctx) {

		String url = ctx.getInitParameter("DBURL");
		String user = ctx.getInitParameter("DBUSER");
		String pass = ctx.getInitParameter("DBPWD");
		String driver = ctx.getInitParameter("DBDRIVER");
		
		String usertype = null;
		
		Connection con=null;
		//PreparedStatement pst=null;
		Statement st=null;
		ResultSet rs=null;
				
		try
		{
			Class.forName(driver);
			con=DriverManager.getConnection(url,user,pass);
			
			st = con.createStatement();
			
			rs = st.executeQuery("select usertype from register1 where userid="+userid+"");

			while(rs.next()) {
				
				usertype = rs.getString("usertype");
				
			}

			//System.out.println("Registration successful");
			
			rs.close();
			st.close();
			//pst.close();
			con.close();
		}
		catch (ClassNotFoundException e) 
		{
			e.printStackTrace();
		}
		catch(SQLException sql)
		{
			sql.printStackTrace();
		}
		
		if(usertype.equals("admin")) {
			return 1;
		}
		else if(usertype.equals("client")) {
			return 2;
		}
		else {
			return 0;
		}
		
	}
	

}

package com.cutm.login;

import java.io.IOException;
//import java.io.PrintWriter;


import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

//import com.rrs.session.ActiveSession;

/**
* Servlet implementation class Login
*/
@WebServlet("/EssLogin")
public class EssLogin extends HttpServlet {
	private static final long serialVersionUID = 1L;
	//private PrintWriter out;
  
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		//out = response.getWriter();
		ServletContext ctx = request.getServletContext();
		
		RequestDispatcher rd = null;
		
		String username = null;
		String password = null;
		String msg = null;
		
		username = request.getParameter("username");
		password = request.getParameter("password1");
		
		
		
		
		CheckLogin checklogin = new CheckLogin();
		//ActiveSession activatesession = new ActiveSession();
		
		HttpSession session = request.getSession();
		
		int userid = 0;
		
		userid=checklogin.validateLogin(username, password, ctx);
			if(userid!=0) {
				
					session.setAttribute("userid",userid);
			    	session.setAttribute("username",username);
					rd = request.getRequestDispatcher("dashboard.jsp");
				}
					
			else {
				
				msg = "INVALID USERNAME or PASSWORD";
				request.setAttribute("msg", msg);
				rd = request.getRequestDispatcher("login.jsp");
				
			}
			
			rd.forward(request, response);
		
	}
}